<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}


class AMS_POSTAX{
    /**
     * Schema for
     * post types, post statuses, tags and taxonomies.
     * 
     * @var array $schemas Holds the schema for 
     * post types, post statuses, tags and taxonomies.
     */
    private $schemas = array();

    /**
     * Sample data for
     * post types, post statuses, tags and taxonomies.
     * 
     * @var array $sample_data Holds the sample data for 
     * post types, post statuses, tags and taxonomies.
     */
    private $sample_data = array();

    /**
     * Lists of
     * post types, post statuses, tags and taxonomies.
     * 
     * @var array $lists Holds the lists of registered
     * post types, post statuses, tags and taxonomies.
     */
    private $lists = array();

    /**
     *  Is REST API request
     * 
     * @var boolean $is_rest defines the status of the request.
     */
    private $is_rest = false;


    /**
     * Clean options
     * If set to true, all post types, taxonomies and tags data in the database will be deleted
     * 
     * @var boolean $clean_options
     */
    private $clean_options = false;

    /**
     * Post type name.
     *
     * @var string $post_type_name Holds the name of the post type.
     */
    public $post_type_name;

    /**
     * Holds the singular name of the post type. This is a human friendly
     * name, capitalized with spaces assigned on __construct().
     *
     * @var string $singular Post type singular name.
     */
    public $singular;

    /**
     * Holds the plural name of the post type. This is a human friendly
     * name, capitalized with spaces assigned on __construct().
     *
     * @var string $plural Singular post type name.
     */
    public $plural;

    /**
     * Post type slug. This is a robot friendly name, all lowercase and uses
     * hyphens assigned on __construct().
     *
     * @var string $slug Holds the post type slug name.
     */
    public $slug;

    /**
     * User submitted options assigned on __construct().
     *
     * @var array $options Holds the user submitted post type options.
     */
    public $options = [];

    /**
     * Taxonomies
     *
     * @var array $taxonomies Holds an array of taxonomies associated with the post type.
     */
    public $taxonomies;

    /**
     * Taxonomy settings, an array of the taxonomies associated with the post
     * type and their options used when registering the taxonomies.
     *
     * @var array $taxonomy_settings Holds the taxonomy settings.
     */
    public $taxonomy_settings;

    /**
     * Taxonomies
     *
     * @var array $taxonomies Holds an array of taxonomies associated with the post type.
     */
    public $post_status;

    /**
     * Taxonomy settings, an array of the taxonomies associated with the post
     * type and their options used when registering the taxonomies.
     *
     * @var array $taxonomy_settings Holds the taxonomy settings.
     */
    public $post_status_settings;

    /**
     * Exisiting taxonomies to be registered after the posty has been registered
     *
     * @var array $exisiting_taxonomies holds exisiting taxonomies
     */
    public $exisiting_taxonomies;

    /**
     * Taxonomy filters. Defines which filters are to appear on admin edit
     * screen used in add_taxonmy_filters().
     *
     * @var array $filters Taxonomy filters.
     */
    public $filters;

    /**
     * Defines which columns are to appear on the admin edit screen used
     * in add_admin_columns().
     *
     * @var array $columns Columns visible in admin edit screen.
     */
    public $columns;

    /**
     * User defined functions to populate admin columns.
     *
     * @var array $custom_populate_columns User functions to populate columns.
     */
    public $custom_populate_columns;

    /**
     * Sortable columns.
     *
     * @var array $sortable Define which columns are sortable on the admin edit screen.
     */
    public $sortable;

    /**
     * Textdomain used for translation. Use the set_textdomain() method to set a custom textdomain.
     *
     * @var string $textdomain Used for internationalising. Defaults to "postax" without quotes.
     */
    public $textdomain = "ams-domain" ;

    /**
     * Args used when registering
     * post types, post statuses, taxonomies and tags.
     * 
     * @var array $args Holds the args used when registering
     */
    public $args;

    /**
     * Constructor
     * 
     * Initialize the class and set its properties.
     */
    public function __construct(){}

    public function init(){
        // Define the schema and other required data
        $this->add_action( 'init', array( &$this, '_preset' ) );

        // Register taxonomies.
        $this->add_action( 'init', array( &$this, 'register_taxonomies' ) );
        
        // Register the post type.
        $this->add_action( 'init', array( &$this, 'register_post_type' ) );

        // Register Post Status.
        $this->add_action( 'init', array( &$this, 'register_post_status' ) );

        // Register exisiting taxonomies.
        $this->add_action( 'init', array( &$this, 'register_exisiting_taxonomies' ) );

        // Add taxonomy to admin edit columns.
        $this->add_filter( 'manage_edit-' . $this->post_type_name . '_columns', array( &$this, 'add_admin_columns' ) );

        // Populate the taxonomy columns with the posts terms.
        $this->add_action( 'manage_' . $this->post_type_name . '_posts_custom_column', array( &$this, 'populate_admin_columns' ), 10, 2 );

        // Add filter select option to admin edit.
        $this->add_action( 'restrict_manage_posts', array( &$this, 'add_taxonomy_filters' ) );

        // rewrite post update messages
        $this->add_filter( 'post_updated_messages', array( &$this, 'updated_messages' ) );
        
        $this->add_filter( 'bulk_post_updated_messages', array( &$this, 'bulk_updated_messages' ), 10, 2 );

        $this->add_action('rest_api_init', array($this, 'route_endpoints'));
    }

    public function _preset(){

        // If not already define by the user, Define the postax directory path
        if( !defined('POSTAX_DIR') )
        define('POSTAX_DIR', dirname( __FILE__ ) . '/postax/');

        // If not already define by the user, Define the postax save directory path
        if( !defined('POSTAX_SAVE_DIR') )
        define('POSTAX_SAVE_DIR', dirname( __FILE__ ) . '/postax/save/');

        // If not already define by the user, Define the postax load directory path
        if( !defined('POSTAX_LOAD_DIR') )
        define('POSTAX_LOAD_DIR', dirname( __FILE__ ) . '/postax/load/');

        // Set the available schema for post types, post statuses, tags and taxonomies
        $this->schemas = apply_filters('ams_postax_schemas', $this->get_data('schemas') );

        // Set the sample data for post types, post statuses, tags and taxonomies
        $this->sample_data = $this->get_data('samples');

        // Set the lists of information for post types, post statuses, tags and taxonomies
        $this->lists = $this->lists();

        // Set the textdomain and allow it to be filtered
        $this->textdomain = apply_filters('ams_postax_textdomain', defined('ABS_DOMAIN') ? ABS_DOMAIN :  $this->textdomain);
        
        // Set the slug name.
        $this->slug = $this->get_slug();

        // Set the plural name label.
        $this->plural = $this->get_plural();

        // Set the singular name label.
        $this->singular = $this->get_singular();

        // Update the lists of post types, post statuses, tags and taxonomies on load
        $this->update_lists();

        // Load available post types from the load directory and/or database
        $this->load_post_type();

        // Load available taxonomies from the load directory and/or database
        $this->load_taxonomy();

        // Set built in and load available post types
        $this->built_in_post_types();

        // Set built in and load available taxonomies
        $this->built_in_taxonomies();

        // Clean all post types, taxonomies and tags data in the database
        if( $this->clean_options === true ) $this->clean_options();
    }

    /**
     * Built default post types
     * 
     * @return void
     * @since 1.0.0
     */
    private function built_in_post_types() {
        // Default post type configuration
        $labels = array(
            'name'                      =>   _x( 'Lists', 'Post Type General Name', ABS_DOMAIN ),
            'singular_name'             =>   _x( 'List', 'Post Type Singular Name', ABS_DOMAIN ),
            'menu_name'                 =>   _x( 'Lists', 'Admin Menu text', ABS_DOMAIN ),
            'name_admin_bar'            =>   _x( 'Lists', 'Add New on Listbar', ABS_DOMAIN ),
            'archives'                  =>   __( 'Lists Archives', ABS_DOMAIN ),
            'attributes'                =>   __( 'Lists Attributes', ABS_DOMAIN ),
            'parent_item_colon'         =>   __( 'Parent lists:', ABS_DOMAIN ),
            'all_items'                 =>   __( 'All lists', ABS_DOMAIN ),
            'add_new_item'              =>   __( 'Add New list', ABS_DOMAIN ),
            'add_new'                   =>   __( 'Add New', ABS_DOMAIN ),
            'new_item'                  =>   __( 'New list', ABS_DOMAIN ),
            'edit_item'                 =>   __( 'Edit list', ABS_DOMAIN ),
            'update_item'               =>   __( 'Update list', ABS_DOMAIN ),
            'view_item'                 =>   __( 'View list', ABS_DOMAIN ),
            'view_items'                =>   __( 'View lists', ABS_DOMAIN ),
            'search_items'              =>   __( 'Search lists', ABS_DOMAIN ),
            'not_found'                 =>   __( 'Not found', ABS_DOMAIN ),
            'not_found_in_trash'        =>   __( 'Not found in Trash', ABS_DOMAIN ),
            'featured_image'            =>   __( 'Featured Image', ABS_DOMAIN ),
            'set_featured_image'        =>   __( 'Set featured image', ABS_DOMAIN ),
            'remove_featured_image'     =>   __( 'Remove featured image', ABS_DOMAIN ),
            'use_featured_image'        =>   __( 'Use as featured image', ABS_DOMAIN ),
            'insert_into_item'          =>   __( 'Insert into Lists', ABS_DOMAIN ),
            'uploaded_to_this_item'     =>   __( 'Uploaded to this Lists', ABS_DOMAIN ),
            'items_list'                =>   __( 'lists list', ABS_DOMAIN ),
            'items_list_navigation'     =>   __( 'lists list navigation', ABS_DOMAIN ),
            'filter_items_list'         =>   __( 'Filter lists list', ABS_DOMAIN ),
        );

        $args = array(
            'label'                     =>  __( 'LISTS', ABS_DOMAIN ),
            'description'               =>  __( '', ABS_DOMAIN ),
            'labels'                    =>  $labels,
            'menu_icon'                 =>  'dashicons-list-view',
            'supports'                  =>  array('title', 'editor', 'revisions'),
            'taxonomies'                =>  array(),
            'public'                    =>  true,
            'show_ui'                   =>  true,
            'show_in_menu'              =>  true,
            'menu_position'             =>  5,
            'show_in_admin_bar'         =>  true,
            'show_in_nav_menus'         =>  true,
            'can_export'                =>  true,
            'has_archive'               =>  true,
            'hierarchical'              =>  false,
            'exclude_from_search'       =>  false,
            'show_in_rest'              =>  true,
            'publicly_queryable'        =>  true,
            'capability_type'           => 'post',
        );

        // Initialize post types
        $post_types = [
            'ams_list' => $args
        ];
    
        // Allow other plugins or themes to modify the post types configuration
        $post_types = apply_filters('ams_postax_post_types', $post_types);

        $save_post_types = [];

        // Loop through each post type configuration and register them
        if( !empty($post_types) ):
            foreach ($post_types as $post_type_name => $args) {
        
                $save_post_types[$post_type_name] = $args;

                // Set the post type properties
                $this->set('post_type_name', $post_type_name);
                $this->set('options', $args);
        
                // Register the post type
                $this->register_post_type();
            }

            $this->save_post_type($save_post_types);
        endif;
    }

    /**
     * Built default taxonomies
     * 
     * @return void
     * @since 1.0.0
     */
    private function built_in_taxonomies() {
        $tag_name = 'ams_tags'; // The taxonomy slug
        $class_name = 'ams_class'; // The taxonomy slug
        $post_type = 'ams_list';     // Change to your custom post type slug

        // Default labels for the taxonomy
        $tag_labels = array(
            'name'                       => _x('Tags', 'taxonomy general name', $this->textdomain),
            'singular_name'              => _x('Tag', 'taxonomy singular name', $this->textdomain),
            'search_items'               => __('Search Tags', $this->textdomain),
            'popular_items'              => __('Popular Tags', $this->textdomain),
            'all_items'                  => __('All Tags', $this->textdomain),
            'parent_item'                => null,
            'parent_item_colon'          => null,
            'edit_item'                  => __('Edit Tag', $this->textdomain),
            'update_item'                => __('Update Tag', $this->textdomain),
            'add_new_item'               => __('Add New Tag', $this->textdomain),
            'new_item_name'              => __('New Tag Name', $this->textdomain),
            'separate_items_with_commas' => __('Separate tags with commas', $this->textdomain),
            'add_or_remove_items'        => __('Add or remove tags', $this->textdomain),
            'choose_from_most_used'      => __('Choose from the most used tags', $this->textdomain),
            'not_found'                  => __('No tags found.', $this->textdomain),
            'menu_name'                  => __('Tags', $this->textdomain),
        );

        // Default arguments for the taxonomy
        $tag_args = array(
            'hierarchical'          => false,
            'labels'                => $tag_labels,
            'show_ui'               => true,
            'show_admin_column'     => true,
            'update_count_callback' => '_update_post_term_count',
            'query_var'             => true,
            'post_type'             => [$post_type],
            'rewrite'               => array('slug' => 'tag'),
        );

        // Default labels for the taxonomy
        $class_labels = array(
            'name'                       => _x('Classes', 'taxonomy general name', $this->textdomain),
            'singular_name'              => _x('Class', 'taxonomy singular name', $this->textdomain),
            'search_items'               => __('Search Classes', $this->textdomain),
            'popular_items'              => __('Popular Classes', $this->textdomain),
            'all_items'                  => __('All Classes', $this->textdomain),
            'parent_item'                => __('Parent Class', $this->textdomain),
            'parent_item_colon'          => __('Parent Class:', $this->textdomain),
            'edit_item'                  => __('Edit Class', $this->textdomain),
            'update_item'                => __('Update Class', $this->textdomain),
            'add_new_item'               => __('Add New Class', $this->textdomain),
            'new_item_name'              => __('New Class Name', $this->textdomain),
            'add_or_remove_items'        => __('Add or remove classes', $this->textdomain),
            'choose_from_most_used'      => __('Choose from the most used classes', $this->textdomain),
            'not_found'                  => __('No classes found.', $this->textdomain),
            'menu_name'                  => __('Classes', $this->textdomain),
        );

        // Default arguments for the taxonomy
        $class_args = array(
            'hierarchical'          => true,
            'labels'                => $class_labels,
            'show_ui'               => true,
            'show_admin_column'     => true,
            'update_count_callback' => '_update_post_term_count',
            'query_var'             => true,
            'post_type'             => [$post_type],
            'rewrite'               => array('slug' => 'class'),
            'default_term'          => [
                'name' => __('Unclassified', $this->textdomain),
                'slug' => __('unclassified', $this->textdomain),
                'description' => __('Unclassified', $this->textdomain),
            ]
        );

        // Initialize taxonomies
        $taxonomies = [
            $class_name => [
                'post_type' => $class_args['post_type'],
                'args' => $class_args
            ],
            $tag_name => [
                'post_type' => $tag_args['post_type'],
                'args' => $tag_args
            ]
        ];

        // Allow other plugins or themes to modify the taxonomies configuration
        $taxonomies = apply_filters('ams_postax_taxonomies', $taxonomies);

        $save_taxonomies = [];

        // Loop through each taxonomy configuration and register them
        if( !empty($taxonomies) ):
            foreach ($taxonomies as $taxonomy_name => $taxonomy) {

                if( !isset($taxonomy['args']) || !isset($taxonomy['post_type']) ) continue;

                $save_taxonomies[$taxonomy_name] = $taxonomy['args'];

                $args = $taxonomy['args'];
                $post_type = $taxonomy['post_type'];

                // Register the taxonomy
                $this->register_taxonomy( $taxonomy_name, $args );
                $this->register_taxonomies();
            }

            $this->save_taxonomy($save_taxonomies);
        endif;
    }

    /**
     * Delete or Reset all
     * post types, taxonomies and tags data in the database
     * 
     * @return void
     */
    private function clean_options(){
        delete_option('ams_postax_post_type_data');
        delete_option('ams_postax_taxonomy_data');
        delete_option('ams_postax_post_type_has_change');
        delete_option('ams_postax_lists');
    }

    /**
     * Register REST API endpoints
     * 
     * @return void
     * @since 1.0.0
     */
    public function route_endpoints() {

        $namespace = 'v1';

        register_rest_route($namespace, '/postax/posttype', array(
            'methods' => 'POST',
            'callback' => array($this, 'create_post_type'),
            'args' => $this->parse_schema( $this->schemas['posttype'] ),
            'permission_callback' => array($this, 'permissions_check')
        ));
    
        register_rest_route($namespace, '/postax/taxonomy', array(
            'methods' => 'POST',
            'callback' => array($this, 'create_taxonomy'),
            'args' => $this->parse_schema( $this->schemas['taxonomy'] ),
            'permission_callback' => array($this, 'permissions_check')
        ));

        // Get lists of post types and taxonomies
        register_rest_route($namespace, '/postax/lists', array(
            'methods' => 'GET',
            'callback' => function () {
                return $this->lists;
            },
            'permission_callback' => array($this, 'permissions_check')
        ));

        register_rest_route($namespace, '/postax/posttype/(?P<post_type>[a-zA-Z0-9_-]+)', array(
            'methods' => 'POST',
            'callback' => array($this, 'update_post_type'),
            'args' => $this->parse_schema( $this->schemas['posttype'] ),
            'permission_callback' => array($this, 'permissions_check')
        ));

        register_rest_route($namespace, '/postax/taxonomy/(?P<taxonomy>[a-zA-Z0-9_-]+)', array(
            'methods' => 'POST',
            'callback' => array($this, 'update_taxonomy'),
            'args' => $this->parse_schema( $this->schemas['taxonomy'] ),
            'permission_callback' => array($this, 'permissions_check')
        ));

        register_rest_route($namespace, '/postax/posttype/(?P<post_type>[a-zA-Z0-9_-]+)', array(
            'methods' => 'DELETE',
            'callback' => array($this, 'delete_post_type'),
            'permission_callback' => array($this, 'permissions_check')
        ));

        register_rest_route($namespace, '/postax/taxonomy/(?P<taxonomy>[a-zA-Z0-9_-]+)', array(
            'methods' => 'DELETE',
            'callback' => array($this, 'delete_taxonomy'),
            'permission_callback' => array($this, 'permissions_check')
        ));
    }
    
    public function permissions_check($request) {
        return current_user_can('manage_options');
    }


    /**
     * Create a new post type via REST API
     * 
     * @param WP_REST_Request $request
     * @return WP_REST_Response
     */
    public function create_post_type( $request ) {
        $params = $request->get_params();

        $post_type = $params['post_type'];

        $args = $params['args'];

        if( isset($this->lists['post_types'], $this->lists['post_types'][$post_type]) ) return new WP_REST_Response( 'Post type not created', 400 );
        
        $this->is_rest = true;

        add_filter('ams_postax_post_types', function($post_types)use($post_type, $args){
            $post_types[$post_type] = $args;
            return $post_types;
        });

        return new WP_REST_Response( 'Post type created', 200 );
    }

    /**
     * Update a post type via REST API
     * 
     * @param WP_REST_Request $request
     * @return WP_REST_Response
     */
    public function update_post_type( $request ) {
        $params = $request->get_params();

        $post_type = $params['post_type'];

        $args = $params['args'];

        if( !isset($this->lists['post_types'], $this->lists['post_types'][$post_type]) ) return new WP_REST_Response( 'Post type not found', 400 );
        
        unlink(POSTAX_SAVE_DIR . $post_type . '-post_types.json');
        unlink(POSTAX_LOAD_DIR . $post_type . '-post_types.json');

        $this->is_rest = true;

        add_filter('ams_postax_post_types', function($post_types)use($post_type, $args){
            $post_types[$post_type] = $args;
            return $post_types;
        });

        unlink(POSTAX_DIR . 'lists.json');

        return new WP_REST_Response( 'Post type updated', 200 );
    }

    /**
     * Delete a post type via REST API
     * 
     * @param WP_REST_Request $request
     * @return WP_REST_Response
     */
    public function delete_post_type( $request ) {
        $params = $request->get_params();

        $post_type = $params['post_type'];

        if( !isset($this->lists['post_types'], $this->lists['post_types'][$post_type]) ) return new WP_REST_Response( 'Post type not found', 400 );
        
        unlink(POSTAX_SAVE_DIR . $post_type . '-post_types.json');
        unlink(POSTAX_LOAD_DIR . $post_type . '-post_types.json');
        unlink(POSTAX_DIR . 'lists.json');

        return new WP_REST_Response( 'Post type deleted', 200 );
    }

    /**
     * Create a new taxonomy via REST API
     * 
     * @param WP_REST_Request $request
     * @return WP_REST_Response
     */
    public function create_taxonomy( $request ) {
        $params = $request->get_params();

        $taxonomy = $params['taxonomy'];

        $args = $params['args'];

        if( isset($this->lists['taxonomies'], $this->lists['taxonomies'][$taxonomy]) ) return new WP_REST_Response( 'Taxonomy not created', 400 );

        $this->is_rest = true;

        add_filter('ams_postax_taxonomies', function($taxonomies)use($taxonomy, $args){
            $taxonomies[$taxonomy] = $args;
            return $taxonomies;
        });

        return new WP_REST_Response( 'Taxonomy created', 200 );
    }

    /**
     * Update a taxonomy via REST API
     * 
     * @param WP_REST_Request $request
     * @return WP_REST_Response
     */
    public function update_taxonomy( $request ) {
        $params = $request->get_params();
        
        $taxonomy = $params['taxonomy'];

        $args = $params['args'];

        if( !isset($this->lists['taxonomies'], $this->lists['taxonomies'][$taxonomy]) ) return new WP_REST_Response( 'Taxonomy not found', 400 );

        unlink(POSTAX_SAVE_DIR . $taxonomy . '-taxonomies.json');
        unlink(POSTAX_LOAD_DIR . $taxonomy . '-taxonomies.json');

        $this->is_rest = true;

        add_filter('ams_postax_taxonomies', function($taxonomies)use($taxonomy, $args){
            $taxonomies[$taxonomy] = $args;
            return $taxonomies;
        });

        unlink(POSTAX_DIR . 'lists.json');
    }

    /**
     * Delete a taxonomy via REST API
     * 
     * @param WP_REST_Request $request
     * @return WP_REST_Response
     */
    public function delete_taxonomy( $request ) {
        $params = $request->get_params();

        $taxonomy = $params['taxonomy'];

        if( !isset($this->lists['taxonomies'], $this->lists['taxonomies'][$taxonomy]) ) return new WP_REST_Response( 'Taxonomy not found', 400 );
        
        unlink(POSTAX_SAVE_DIR . $taxonomy . '-taxonomies.json');
        unlink(POSTAX_LOAD_DIR . $taxonomy . '-taxonomies.json');
        unlink(POSTAX_DIR . 'lists.json');

        return new WP_REST_Response( 'Taxonomy deleted', 200 );
    }

    /**
     * Save post type data to JSON file and/or database
     * 
     * @return void
     * @since 1.0.0
     */
    private function save_post_type( $post_type_data ) {

        $postax_has_change = filter_var(get_option('ams_postax_post_type_has_change', true), FILTER_VALIDATE_BOOLEAN);

        $post_type_option = get_option('ams_postax_post_type_data', []);
        
        if( $postax_has_change === false && $this->verify_arrays_are_similar($post_type_option, $post_type_data) ) return false;
      
        if( $post_type_option == false ){
            update_option('ams_postax_post_type_data', $post_type_data);            
        } else {
            $post_type_data = array_merge($post_type_option, $post_type_data);
            update_option('ams_postax_post_type_data', $post_type_data);
        }

        
        foreach ($post_type_data as $postname => $value) {
            $json_data = json_encode($value, JSON_PRETTY_PRINT);
            file_put_contents(POSTAX_SAVE_DIR . $postname . '-post_types.json', $json_data);
                
            if( $this->is_rest === true )
            file_put_contents(POSTAX_LOAD_DIR . $postname . '-post_types.json', $json_data);
        }

        $this->update_lists();

        update_option('ams_postax_post_type_has_change', false);

        return true;
    }

    /**
     * Save taxonomy data to JSON file and/or database
     * 
     * @return void
     * @since 1.0.0
     */
    private function save_taxonomy( $taxonomy_data, $type = null ) {
        
        $postax_has_change = filter_var(get_option('ams_postax_taxonomy_has_change', true), FILTER_VALIDATE_BOOLEAN);

        $taxonomy_option = get_option('ams_postax_taxonomy_data', []);

        if( $postax_has_change == false && $this->verify_arrays_are_similar($taxonomy_option, $taxonomy_data) ) return false;

        if( $taxonomy_option !== false ){
            update_option('ams_postax_taxonomy_data', $taxonomy_data);            
        } else {
            $taxonomy_data = array_merge($taxonomy_option, $taxonomy_data);
            update_option('ams_postax_taxonomy_data', $taxonomy_data);
        }

        // Save to JSON file
        foreach ($taxonomy_data as $taxonomy_name => $value) {
            $json_data = json_encode($value, JSON_PRETTY_PRINT);
            file_put_contents(POSTAX_SAVE_DIR . $taxonomy_name . '-taxonomies.json', $json_data);

            if( $type == 'rest' )
            file_put_contents(POSTAX_LOAD_DIR . $taxonomy_name . '-taxonomies.json', $json_data);
        }

        $this->update_lists();

        update_option('ams_postax_taxonomy_has_change', false);
    }

    /**
     * Verify if two arrays are similar
     * 
     * @return boolean
     * @since 1.0.0
     */
    private function verify_arrays_are_similar($array1, $array2) {
        foreach ($array2 as $key => $value) {
            if (!array_key_exists($key, $array1) || $array1[$key] !== $value) {
                return false;
            }
        }
    
        return true;
    }

    /**
     * Load post type from JSON file and/or database
     * 
     * @return void
     * @since 1.0.0
     */
    public function load_post_type() {
        
        $load_dir = apply_filters('ams_postax_load_path', [POSTAX_LOAD_DIR]);

        $post_type_data = [];
        
        // $post_types = get_option('ams_postax_post_type_data', []);

        foreach ($load_dir as $dir) {
            $files = glob($dir . '*.json');
            
            foreach ($files as $file) {
                $post_type_slug = basename($file, '-post_types.json');

                
                // if(!isset($post_types[$post_type_slug])) continue;

                $post_type_data[$post_type_slug] = json_decode(file_get_contents($file), true);
            }
        }
        
        if( !empty($post_type_data) )
        add_filter('ams_postax_post_types', function($post_types)use($post_type_data){
            $post_types = array_merge($post_types, $post_type_data);
            return $post_types;
        });
    }

    /**
     * Load taxonomy from JSON file and/or database
     * 
     * @return void
     * @since 1.0.0
     */
    public function load_taxonomy() {
        $load_dir = apply_filters('ams_postax_load_path', [POSTAX_LOAD_DIR]);

        $taxonomy_data = [];
        
        // $taxonomies = get_option('ams_postax_taxonomy_data', []);

        foreach ($load_dir as $dir) {
            $files = glob($dir . '*.json');
            
            foreach ($files as $file) {
                $taxonomy_slug = basename($file, '-taxonomies.json');

                // if(!isset($taxonomies[$taxonomy_slug])) continue;
                
                $taxonomy_data[$taxonomy_slug] = json_decode(file_get_contents($file), true);
            }
        }

        add_filter('ams_postax_taxonomies', function($taxonomies)use($taxonomy_data){
            $taxonomies = array_merge($taxonomies, $taxonomy_data);
            return $taxonomies;
        });
    }

    
    /**
     * Get lists of information for 
     * post types, post statuses, tags and taxonomies
     * 
     * @return array
     * @since 1.0.0
     */
    private function lists() {
        $list = get_option('ams_postax_lists', array());

        // Optionally filter or modify the list as required
        return $list;
    }

    /**
     * Update lists of information for
     * post types, post statuses, tags and taxonomies
     * 
     * @return void
     */
    public function update_lists( $force = false ) {
        $file_name = POSTAX_DIR . 'lists.json';

        $post_type_data = get_option('ams_postax_post_type_data', array());
        $taxonomy_data = get_option('ams_postax_taxonomy_data', array());

        $list_postax = get_option('ams_postax_lists', array());
        
        if( !file_exists($file_name) ){
            update_option('ams_postax_post_type_has_change', true);
            update_option('ams_postax_taxonomy_has_change', true);

            $force = true;

        }elseif( empty($list_postax) ){
            update_option('ams_postax_post_type_has_change', true);
            update_option('ams_postax_taxonomy_has_change', true);

            $force = true;
        }

        if( $force === false ) return;

        $tracking_data = array(
            'count' => [
                'post_types' => $post_type_data ? count($post_type_data) : 0,
                'taxonomies' => $taxonomy_data ? count($taxonomy_data) : 0
            ],
            'post_types' =>$post_type_data,
            'taxonomies' => $taxonomy_data
        );

        if( json_encode($list_postax) !== json_encode($tracking_data))
        update_option('ams_postax_lists', $tracking_data);
    
        // Optionally, save to a JSON file
        $json_data = json_encode($tracking_data, JSON_PRETTY_PRINT);
        file_put_contents($file_name, $json_data);
    }

    /**
     * Get data from JSON file
     * 
     * @return array
     * @since 1.0.0
     */
    public function get_data( $name ){

        $file_name = POSTAX_DIR . $name . '.json';

        $data = false;

        if( !file_exists($file_name) ){
            $file_name = POSTAX_DIR . $name;

            if( !file_exists($file_name) )  $data = false;
            else $data = file_get_contents($file_name);

        }else{
            $json_data = file_get_contents($file_name);

            $data = json_decode($json_data, true);
        }

        return $data;
    }

    /**
     * Format schema for suitable use in the REST API
     * 
     * @param array $schema The schema to parse
     * @return array The parsed schema
     */
    public function parse_schema($schema) {
        $parsed_schema = [];
    
        // Function to recursively parse each schema part
        $parse_part = function ($part, $required_keys) use (&$parse_part) {
            $parsed_part = [];
    
            foreach ($part as $key => $value) {
                if (is_array($value)) {
                    // Check if it's a schema definition or a nested property
                    if (isset($value['type'])) {
                        $parsed_part[$key] = $value;
    
                        // Set 'required' if in the required array for this level
                        if (in_array($key, $required_keys, true)) {
                            $parsed_part[$key]['required'] = true;
                        }
    
                        // Recursively parse properties if they exist
                        if (isset($value['properties'])) {
                            $nested_required = $value['required'] ?? [];
                            $parsed_part[$key]['properties'] = $parse_part($value['properties'], $nested_required);
                        }
                    } else {
                        // Assume it's a nested property without a 'type' field
                        $parsed_part[$key] = $parse_part($value, $required_keys);
                    }
                } else {
                    // Direct assignment for non-array values
                    $parsed_part[$key] = $value;
                }
            }
    
            return $parsed_part;
        };
    
        // Start parsing with the top-level required keys
        $top_level_required = $schema['required'] ?? [];
        $parsed_schema = $parse_part($schema, $top_level_required);
    
        return $parsed_schema;
    }


    /**
     * Get
     *
     * Helper function to get an object variable.
     *
     * @param string $var The variable you would like to retrieve.
     * @return mixed Returns the value on success, boolean false whe it fails.
     */
    public function get( $var ) {

        // If the variable exists.
        if ( self::$$var ) {

            // On success return the value.
            return self::$$var;

        } else {

            // on fail return false
            return false;
        }
    }

    /**
     * Set
     *
     * Helper function used to set an object variable. Can overwrite existsing
     * variables or create new ones. Cannot overwrite reserved variables.
     *
     * @param mixed $var The variable you would like to create/overwrite.
     * @param mixed $value The value you would like to set to the variable.
     */
    public function set( $var, $value ) {
        // An array of reserved variables that cannot be overwritten.
        $reserved = array(
            'config',
            'post_type_name',
            'singular',
            'plural',
            'slug',
            'options',
            'taxonomies'
        );

        // If the variable is not a reserved variable
        if (  in_array( $var, $reserved ) ) {

            // Write variable and value
            $this->$var = $value;
        }
    }

    /**
     * Add Action
     *
     * Helper function to add add_action WordPress filters.
     *
     * @param string $action Name of the action.
     * @param string $function Function to hook that will run on action.
     * @param integer $priority Order in which to execute the function, relation to other functions hooked to this action.
     * @param integer $accepted_args The number of arguments the function accepts.
     */
    public function add_action( $action, $function, $priority = 10, $accepted_args = 1 ) {

        // Pass variables into WordPress add_action function
        add_action( $action, $function, $priority, $accepted_args );
    }

    /**
     * Add Filter
     *
     * Create add_filter WordPress filter.
     *
     * @see http://wpx.wordpress.org/Function_Reference/add_filter
     *
     * @param  string  $action           Name of the action to hook to, e.g 'init'.
     * @param  string  $function         public function to hook that will run on @action.
     * @param  int     $priority         Order in which to execute the function, relation to other function hooked to this action.
     * @param  int     $accepted_args    The number of arguements the function accepts.
     */
    public function add_filter( $action, $function, $priority = 10, $accepted_args = 1 ) {

        // Pass variables into Wordpress add_action function
        add_filter( $action, $function, $priority, $accepted_args );
    }

    /**
     * Get slug
     *
     * Creates an url friendly slug.
     *
     * @param  string $name Name to slugify.
     * @return string $name Returns the slug.
     */
    public function get_slug( $name = null ) {

        // If no name set use the post type name.
        if ( ! isset( $name ) ) {

            $name = $this->post_type_name;
        }

        // Name to lower case.
        $name = strtolower( $name );

        // Replace spaces with hyphen.
        $name = str_replace( " ", "-", $name );

        // Replace underscore with hyphen.
        $name = str_replace( "_", "-", $name );

        return $name;
    }

    /**
     * Get plural
     *
     * Returns the friendly plural name.
     *
     *    ucwords      capitalize words
     *    strtolower   makes string lowercase before capitalizing
     *    str_replace  replace all instances of _ to space
     *
     * @param  string $name The slug name you want to pluralize.
     * @return string the friendly pluralized name.
     */
    public function get_plural( $name = null ) {

        // If no name is passed the post_type_name is used.
        if ( ! isset( $name ) ) {

            $name = $this->post_type_name;
        }

        // Return the plural name. Add 's' to the end.
        return $this->get_human_friendly( $name ) . 's';
    }

    /**
     * Get singular
     *
     * Returns the friendly singular name.
     *
     *    ucwords      capitalize words
     *    strtolower   makes string lowercase before capitalizing
     *    str_replace  replace all instances of _ to space
     *
     * @param string $name The slug name you want to unpluralize.
     * @return string The friendly singular name.
     */
    public function get_singular( $name = null ) {

        // If no name is passed the post_type_name is used.
        if ( ! isset( $name ) ) {

            $name = $this->post_type_name;

        }

        // Return the string.
        return $this->get_human_friendly( $name );
    }

    /**
     * Get human friendly
     *
     * Returns the human friendly name.
     *
     *    ucwords      capitalize words
     *    strtolower   makes string lowercase before capitalizing
     *    str_replace  replace all instances of hyphens and underscores to spaces
     *
     * @param string $name The name you want to make friendly.
     * @return string The human friendly name.
     */
    public function get_human_friendly( $name = null ) {

        // If no name is passed the post_type_name is used.
        if ( ! isset( $name ) ) {

            $name = $this->post_type_name;
        }

        // Return human friendly name.
        return ucwords( strtolower( str_replace( "-", " ", str_replace( "_", " ", $name ) ) ) );
    }

    /**
     * Register Post Type
     *
     * @see http://wpx.wordpress.org/Function_Reference/register_post_type
     */
    public function register_post_type() {

        // Friendly post type names.
        $plural   = $this->plural;
        $singular = $this->singular;
        $slug     = $this->slug;

        // Default labels.
        $labels = array(
            'name'               => sprintf( __( '%s', $this->textdomain ), $plural ),
            'singular_name'      => sprintf( __( '%s', $this->textdomain ), $singular ),
            'menu_name'          => sprintf( __( '%s', $this->textdomain ), $plural ),
            'all_items'          => sprintf( __( '%s', $this->textdomain ), $plural ),
            'add_new'            => __( 'Add New', $this->textdomain ),
            'add_new_item'       => sprintf( __( 'Add New %s', $this->textdomain ), $singular ),
            'edit_item'          => sprintf( __( 'Edit %s', $this->textdomain ), $singular ),
            'new_item'           => sprintf( __( 'New %s', $this->textdomain ), $singular ),
            'view_item'          => sprintf( __( 'View %s', $this->textdomain ), $singular ),
            'search_items'       => sprintf( __( 'Search %s', $this->textdomain ), $plural ),
            'not_found'          => sprintf( __( 'No %s found', $this->textdomain ), $plural ),
            'not_found_in_trash' => sprintf( __( 'No %s found in Trash', $this->textdomain ), $plural ),
            'parent_item_colon'  => sprintf( __( 'Parent %s:', $this->textdomain ), $singular )
        );

        // Default options.
        $defaults = array(
            'labels' => $labels,
            'public' => true,
            'rewrite' => array(
                'slug' => $slug,
            )
        );

        // Merge user submitted options with defaults.
        $options = array_replace_recursive( $defaults, $this->options );

        // Set the object options as full options passed.
        $this->options = $options;

        // Check that the post type doesn't already exist.
        if ( ! post_type_exists( $this->post_type_name ) ) {

            // Register the post type.
            register_post_type( $this->post_type_name, $options );
        }
    }

    /**
     * Register taxonomy
     *
     * @see http://wpx.wordpress.org/Function_Reference/register_taxonomy
     *
     * @param string $taxonomy_name The slug for the taxonomy.
     * @param array  $options Taxonomy options.
     */
    public function register_taxonomy($taxonomy_names, $options = array()) {

        // Post type defaults to $this post type if unspecified.
        $post_type = $this->post_type_name;

        // An array of the names required excluding taxonomy_name.
        $names = array(
            'singular',
            'plural',
            'slug'
        );

        // if an array of names are passed
        if ( is_array( $taxonomy_names ) ) {

            // Set the taxonomy name
            $taxonomy_name = $taxonomy_names['taxonomy_name'];

            // Cycle through possible names.
            foreach ( $names as $name ) {

                // If the user has set the name.
                if ( isset( $taxonomy_names[ $name ] ) ) {

                    // Use user submitted name.
                    $$name = $taxonomy_names[ $name ];

                    // Else generate the name.
                } else {

                    // Define the function to be used.
                    $method = 'get_' . $name;

                    // Generate the name
                    $$name = $this->$method( $taxonomy_name );

                }
            }

            // Else if only the taxonomy_name has been supplied.
        } else  {

            // Create user friendly names.
            $taxonomy_name = $taxonomy_names;
            $singular = $this->get_singular( $taxonomy_name );
            $plural   = $this->get_plural( $taxonomy_name );
            $slug     = $this->get_slug( $taxonomy_name );

        }

        // Default labels.
        $labels = array(
            'name'                       => sprintf( __( '%s', $this->textdomain ), $plural ),
            'singular_name'              => sprintf( __( '%s', $this->textdomain ), $singular ),
            'menu_name'                  => sprintf( __( '%s', $this->textdomain ), $plural ),
            'all_items'                  => sprintf( __( 'All %s', $this->textdomain ), $plural ),
            'edit_item'                  => sprintf( __( 'Edit %s', $this->textdomain ), $singular ),
            'view_item'                  => sprintf( __( 'View %s', $this->textdomain ), $singular ),
            'update_item'                => sprintf( __( 'Update %s', $this->textdomain ), $singular ),
            'add_new_item'               => sprintf( __( 'Add New %s', $this->textdomain ), $singular ),
            'new_item_name'              => sprintf( __( 'New %s Name', $this->textdomain ), $singular ),
            'parent_item'                => sprintf( __( 'Parent %s', $this->textdomain ), $plural ),
            'parent_item_colon'          => sprintf( __( 'Parent %s:', $this->textdomain ), $plural ),
            'search_items'               => sprintf( __( 'Search %s', $this->textdomain ), $plural ),
            'popular_items'              => sprintf( __( 'Popular %s', $this->textdomain ), $plural ),
            'separate_items_with_commas' => sprintf( __( 'Seperate %s with commas', $this->textdomain ), $plural ),
            'add_or_remove_items'        => sprintf( __( 'Add or remove %s', $this->textdomain ), $plural ),
            'choose_from_most_used'      => sprintf( __( 'Choose from most used %s', $this->textdomain ), $plural ),
            'not_found'                  => sprintf( __( 'No %s found', $this->textdomain ), $plural ),
        );

        // Default options.
        $defaults = array(
            'labels' => $labels,
            'hierarchical' => true,
            'rewrite' => array(
                'slug' => $slug
            )
        );

        // Merge default options with user submitted options.
        $options = array_replace_recursive( $defaults, $options );

        // Add the taxonomy to the object array, this is used to add columns and filters to admin panel.
        $this->taxonomies[] = $taxonomy_name;

        // Create array used when registering taxonomies.
        $this->taxonomy_settings[ $taxonomy_name ] = $options;

    }



    /**
     * Register Post Statuses
     *
     * Cycles through post status added with the class and registers them.
     */
    public function post_status($status_names, $options = array()) {

        $names = [
            'label',
        ];

        // if an array of names are passed
        if ( is_array( $status_names ) ) {

            // Set the status name
            $status_name = $status_names['name'];

            // Cycle through possible names.
            foreach ( $names as $name ) {

                // If the user has set the name.
                if ( isset( $status_names[ $name ] ) ) {

                    // Use user submitted name.
                    $$name = $status_names[ $name ];

                    // Else generate the name.
                } elseif( method_exists($this, 'get_' . $name ) && $method = 'get_' . $name ) {
                    // Generate the name
                    $$name = $this->$method( $status_name );
                }
            }

            // Else if only the has been supplied.
        } else  {
            // Create user friendly names.
            $status_name = $status_names;
            $label = $this->get_singular( $status_name );
        }

        // Default args.
        $args = array(
            'label'                       => sprintf( __( '%s', $this->textdomain ), $label ),
            'public'                    => true,
            'exclude_from_search'       => false,
            'show_in_admin_all_list'    => true,
            'show_in_admin_status_list' => true,
            'label_count'               => _n_noop( $label .' <span class="count">(%s)</span>', $label .' <span class="count">(%s)</span>' ),
        );

        // Default options.
        $defaults = $args;

        // Merge default options with user submitted options.
        $options = array_replace_recursive( $defaults, $options );

        // Add the status name to the object array, this is used to add columns and filters to admin panel.
        $this->post_status[] = $status_name;

        // Create array used when registering taxonomies.
        $this->post_status_settings[ $status_name ] = $options;
    }


    /**
     * Register Post Statuses
     *
     * Cycles through post_statuses added with the class and registers them.
     */
    public function register_post_status() {
        
        if ( is_array( $this->post_status_settings ) ) {
            
            // Foreach taxonomy registered with the post type.
            foreach ( $this->post_status_settings as $post_status_name => $options ) {
                register_post_status($post_status_name, $options);

                // Submit Box
                add_action( 'post_submitbox_misc_actions', function()use($post_status_name, $options){
                    global $post;

                    if( $post->post_type != $this->post_type_name ) return false;
            
                    $status = ($post->post_status == $post_status_name ) ? "jQuery( '#post-status-display' ).text( '$options[label]' );
                    jQuery( 'select[name=\"post_status\"]' ).val('$post_status_name');" : '';
                    echo "<script>
                    jQuery(document).ready( function() {
                    jQuery( 'select[name=\"post_status\"]' ).append( '<option value=\"$post_status_name\">$options[label]</option>' );
                    ".$status."
                    });
                    </script>";
                });

                //Quick Edit
                add_action( 'admin_footer-edit.php', function()use($post_status_name, $options){
                    global $post;
                    if( $post->post_type != $this->post_type_name ) return false;
                    echo "<script>
                    jQuery(document).ready( function() {
                        jQuery( 'select[name=\"_status\"]' ).append( '<option value=\"$post_status_name\">$options[label]</option>' );
                    });
                    </script>";
                });

                //Archive State
                add_action( 'display_post_states', function( $states )use($post_status_name, $options){
                    global $post;
                    $arg = get_query_var( 'post_status' );
                    if($arg != $post_status_name){
                        if($post->post_status == $post_status_name){
                            echo "<script>
                            jQuery(document).ready( function() {
                            jQuery( '#post-status-display' ).text( $options[label] );
                            });
                            </script>";
                            return array($options['label']);
                        }
                    }
                    return $states;
                });
            }
        }
    }


    /**
     * Register taxonomies
     *
     * Cycles through taxonomies added with the class and registers them.
     */
    public function register_taxonomies() {

        if ( is_array( $this->taxonomy_settings ) ) {

            // Foreach taxonomy registered with the post type.
            foreach ( $this->taxonomy_settings as $taxonomy_name => $options ) {

                // Register the taxonomy if it doesn't exist.
                if ( ! taxonomy_exists( $taxonomy_name ) ) {

                    // Register the taxonomy with Wordpress
                    register_taxonomy( $taxonomy_name, $this->post_type_name, $options );

                } else {

                    // If taxonomy exists, register it later with register_exisiting_taxonomies
                    $this->exisiting_taxonomies[] = $taxonomy_name;
                }
            }
        }
    }

    /**
     * Register Exisiting Taxonomies
     *
     * Cycles through exisiting taxonomies and registers them after the post type has been registered
     */
    public function register_exisiting_taxonomies() {

        if( is_array( $this->exisiting_taxonomies ) ) {
            foreach( $this->exisiting_taxonomies as $taxonomy_name ) {
                register_taxonomy_for_object_type( $taxonomy_name, $this->post_type_name );
            }
        }
    }

    /**
     * Add admin columns
     *
     * Adds columns to the admin edit screen. Function is used with add_action
     *
     * @param array $columns Columns to be added to the admin edit screen.
     * @return array
     */
    public function add_admin_columns( $columns ) {

        // If no user columns have been specified, add taxonomies
        if ( ! isset( $this->columns ) ) {

            $new_columns = array();

            // determine which column to add custom taxonomies after
            if ( is_array( $this->taxonomies ) && in_array( 'post_tag', $this->taxonomies ) || $this->post_type_name === 'post' ) {
                $after = 'tags';
            } elseif( is_array( $this->taxonomies ) && in_array( 'category', $this->taxonomies ) || $this->post_type_name === 'post' ) {
                $after = 'categories';
            } elseif( post_type_supports( $this->post_type_name, 'author' ) ) {
                $after = 'author';
            } else {
                $after = 'title';
            }

            // foreach exisiting columns
            foreach( $columns as $key => $title ) {

                // add exisiting column to the new column array
                $new_columns[$key] = $title;

                // we want to add taxonomy columns after a specific column
                if( $key === $after ) {

                    // If there are taxonomies registered to the post type.
                    if ( is_array( $this->taxonomies ) ) {

                        // Create a column for each taxonomy.
                        foreach( $this->taxonomies as $tax ) {

                            // WordPress adds Categories and Tags automatically, ignore these
                            if( $tax !== 'category' && $tax !== 'post_tag' ) {
                                // Get the taxonomy object for labels.
                                $taxonomy_object = get_taxonomy( $tax );

                                // Column key is the slug, value is friendly name.
                                $new_columns[ $tax ] = sprintf( __( '%s', $this->textdomain ), $taxonomy_object->labels->name );
                            }
                        }
                    }
                }
            }

            // overide with new columns
            $columns = $new_columns;

        } else {

            // Use user submitted columns, these are defined using the object columns() method.
            $columns = $this->columns;
        }

        return $columns;
    }

    /**
     * Populate admin columns
     *
     * Populate custom columns on the admin edit screen.
     *
     * @param string $column The name of the column.
     * @param integer $post_id The post ID.
     */
    public function populate_admin_columns( $column, $post_id ) {

        // Get wordpress $post object.
        global $post;

        // determine the column
        switch( $column ) {

            // If column is a taxonomy associated with the post type.
            case ( taxonomy_exists( $column ) ) :

                // Get the taxonomy for the post
                $terms = get_the_terms( $post_id, $column );

                // If we have terms.
                if ( ! empty( $terms ) ) {

                    $output = array();

                    // Loop through each term, linking to the 'edit posts' page for the specific term.
                    foreach( $terms as $term ) {

                        // Output is an array of terms associated with the post.
                        $output[] = sprintf(

                            // Define link.
                            '<a href="%s">%s</a>',

                            // Create filter url.
                            esc_url( add_query_arg( array( 'post_type' => $post->post_type, $column => $term->slug ), 'edit.php' ) ),

                            // Create friendly term name.
                            esc_html( sanitize_term_field( 'name', $term->name, $term->term_id, $column, 'display' ) )
                        );

                    }

                    // Join the terms, separating them with a comma.
                    echo join( ', ', $output );

                // If no terms found.
                } else {

                    // Get the taxonomy object for labels
                    $taxonomy_object = get_taxonomy( $column );

                    // Echo no terms.
                    printf( __( 'No %s', $this->textdomain ), $taxonomy_object->labels->name );
                }

            break;

            // If column is for the post ID.
            case 'post_id' :

                echo $post->ID;

            break;

            // if the column is prepended with 'meta_', this will automagically retrieve the meta values and display them.
            case ( preg_match( '/^meta_/', $column ) ? true : false ) :

                // meta_book_author (meta key = book_author)
                $x = substr( $column, 5 );

                $meta = get_post_meta( $post->ID, $x );

                echo join( ", ", $meta );

            break;

            // If the column is post thumbnail.
            case 'icon' :

                // Create the edit link.
                $link = esc_url( add_query_arg( array( 'post' => $post->ID, 'action' => 'edit' ), 'post.php' ) );

                // If it post has a featured image.
                if ( has_post_thumbnail() ) {

                    // Display post featured image with edit link.
                    echo '<a href="' . $link . '">';
                        the_post_thumbnail( array(60, 60) );
                    echo '</a>';

                } else {

                    // Display default media image with link.
                    echo '<a href="' . $link . '"><img src="'. site_url( '/wp-includes/images/crystal/default.png' ) .'" alt="' . $post->post_title . '" /></a>';

                }

            break;

            // Default case checks if the column has a user function, this is most commonly used for custom fields.
            default :

                // If there are user custom columns to populate.
                if ( isset( $this->custom_populate_columns ) && is_array( $this->custom_populate_columns ) ) {

                    // If this column has a user submitted function to run.
                    if ( isset( $this->custom_populate_columns[ $column ] ) && is_callable( $this->custom_populate_columns[ $column ] ) ) {

                        // Run the function.
                        call_user_func_array(  $this->custom_populate_columns[ $column ], array( $column, $post ) );

                    }
                }

            break;
        } // end switch( $column )
    }

    /**
     * Filters
     *
     * User function to define which taxonomy filters to display on the admin page.
     *
     * @param array $filters An array of taxonomy filters to display.
     */
    public function filters( $filters = array() ) {

        $this->filters = $filters;
    }

    /**
     *  Add taxtonomy filters
     *
     * Creates select fields for filtering posts by taxonomies on admin edit screen.
    */
    public function add_taxonomy_filters() {

        global $typenow;
        global $wp_query;

        // Must set this to the post type you want the filter(s) displayed on.
        if ( $typenow == $this->post_type_name ) {

            // if custom filters are defined use those
            if ( is_array( $this->filters ) ) {

                $filters = $this->filters;

            // else default to use all taxonomies associated with the post
            } else {

                $filters = $this->taxonomies;
            }

            if ( ! empty( $filters ) ) {

                // Foreach of the taxonomies we want to create filters for...
                foreach ( $filters as $tax_slug ) {

                    // ...object for taxonomy, doesn't contain the terms.
                    $tax = get_taxonomy( $tax_slug );

                    // Get taxonomy terms and order by name.
                    $args = array(
                        'orderby' => 'name',
                        'hide_empty' => false
                    );

                    // Get taxonomy terms.
                    $terms = get_terms( $tax_slug, $args );

                    // If we have terms.
                    if ( $terms ) {

                        // Set up select box.
                        printf( ' &nbsp;<select name="%s" class="postform">', $tax_slug );

                        // Default show all.
                        printf( '<option value="0">%s</option>', sprintf( __( 'Show all %s', $this->textdomain ), $tax->label ) );

                        // Foreach term create an option field...
                        foreach ( $terms as $term ) {

                            // ...if filtered by this term make it selected.
                            if ( isset( $_GET[ $tax_slug ] ) && $_GET[ $tax_slug ] === $term->slug ) {

                                printf( '<option value="%s" selected="selected">%s (%s)</option>', $term->slug, $term->name, $term->count );

                            // ...create option for taxonomy.
                            } else {

                                printf( '<option value="%s">%s (%s)</option>', $term->slug, $term->name, $term->count );
                            }
                        }
                        // End the select field.
                        print( '</select>&nbsp;' );
                    }
                }
            }
        }
    }

    /**
     * Columns
     *
     * Choose columns to be displayed on the admin edit screen.
     *
     * @param array $columns An array of columns to be displayed.
     */
    public function columns( $columns ) {

        // If columns is set.
        if( isset( $columns ) ) {

            // Assign user submitted columns to object.
            $this->columns = $columns;

        }
    }

    /**
     * Populate columns
     *
     * Define what and how to populate a speicific admin column.
     *
     * @param string $column_name The name of the column to populate.
     * @param mixed $callback An anonyous function or callable array to call when populating the column.
     */
    public function populate_column( $column_name, $callback ) {

        $this->custom_populate_columns[ $column_name ] = $callback;

    }

    /**
     * Sortable
     *
     * Define what columns are sortable in the admin edit screen.
     *
     * @param array $columns An array of columns that are sortable.
     */
    public function sortable( $columns = array() ) {

        // Assign user defined sortable columns to object variable.
        $this->sortable = $columns;

        // Run filter to make columns sortable.
        $this->add_filter( 'manage_edit-' . $this->post_type_name . '_sortable_columns', array( &$this, 'make_columns_sortable' ) );

        // Run action that sorts columns on request.
        $this->add_action( 'load-edit.php', array( &$this, 'load_edit' ) );
    }

    /**
     * Make columns sortable
     *
     * Internal function that adds user defined sortable columns to WordPress default columns.
     *
     * @param array $columns Columns to be sortable.
     *
     */
    public function make_columns_sortable( $columns ) {

        // For each sortable column.
        foreach ( $this->sortable as $column => $values ) {

            // Make an array to merge into wordpress sortable columns.
            $sortable_columns[ $column ] = $values[0];
        }

        // Merge sortable columns array into wordpress sortable columns.
        $columns = array_merge( $sortable_columns, $columns );

        return $columns;
    }

    /**
     * Load edit
     *
     * Sort columns only on the edit.php page when requested.
     *
     * @see http://wpx.wordpress.org/Plugin_API/Filter_Reference/request
     */
    public function load_edit() {

        // Run filter to sort columns when requested
        $this->add_filter( 'request', array( &$this, 'sort_columns' ) );

    }

    /**
     * Sort columns
     *
     * Internal function that sorts columns on request.
     *
     * @see load_edit()
     *
     * @param array $vars The query vars submitted by user.
     * @return array A sorted array.
     */
    public function sort_columns( $vars ) {

        // Cycle through all sortable columns submitted by the user
        foreach ( $this->sortable as $column => $values ) {

            // Retrieve the meta key from the user submitted array of sortable columns
            $meta_key = $values[0];

            // If the meta_key is a taxonomy
            if( taxonomy_exists( $meta_key ) ) {

                // Sort by taxonomy.
                $key = "taxonomy";

            } else {

                // else by meta key.
                $key = "meta_key";
            }

            // If the optional parameter is set and is set to true
            if ( isset( $values[1] ) && true === $values[1] ) {

                // Vaules needed to be ordered by integer value
                $orderby = 'meta_value_num';

            } else {

                // Values are to be order by string value
                $orderby = 'meta_value';
            }

            // Check if we're viewing this post type
            if ( isset( $vars['post_type'] ) && $this->post_type_name == $vars['post_type'] ) {

                // find the meta key we want to order posts by
                if ( isset( $vars['orderby'] ) && $meta_key == $vars['orderby'] ) {

                    // Merge the query vars with our custom variables
                    $vars = array_merge(
                        $vars,
                        array(
                            'meta_key' => $meta_key,
                            'orderby' => $orderby
                        )
                    );
                }
            }
        }
        return $vars;
    }

    /**
     * Set menu icon
     *
     * Use this function to set the menu icon in the admin dashboard. Since WordPress v3.8
     * dashicons are used. For more information see @link http://melchoyce.github.io/dashicons/
     *
     * @param string $icon dashicon name
     */
    public function menu_icon( $icon = "dashicons-admin-page" ) {

        if ( is_string( $icon ) && stripos( $icon, "dashicons" ) !== false ) {

            $this->options["menu_icon"] = $icon;

        } else {

            // Set a default menu icon
            $this->options["menu_icon"] = "dashicons-admin-page";
        }
    }

    /**
     * Set textdomain
     *
     * @param string $textdomain Textdomain used for translation.
     */
    public function set_textdomain( $textdomain ) {
        $this->textdomain = $textdomain;
    }

    /**
     * Updated messages
     *
     * Internal function that modifies the post type names in updated messages
     *
     * @param array $messages an array of post updated messages
     */
    public function updated_messages( $messages ) {

        $post = get_post();
        $singular = $this->singular;

        $messages[$this->post_type_name] = array(
            0 => '',
            1 => sprintf( __( '%s updated.', $this->textdomain ), $singular ),
            2 => __( 'Custom field updated.', $this->textdomain ),
            3 => __( 'Custom field deleted.', $this->textdomain ),
            4 => sprintf( __( '%s updated.', $this->textdomain ), $singular ),
            5 => isset( $_GET['revision'] ) ? sprintf( __( '%2$s restored to revision from %1$s', $this->textdomain ), wp_post_revision_title( (int) $_GET['revision'], false ), $singular ) : false,
            6 => sprintf( __( '%s updated.', $this->textdomain ), $singular ),
            7 => sprintf( __( '%s saved.', $this->textdomain ), $singular ),
            8 => sprintf( __( '%s submitted.', $this->textdomain ), $singular ),
            9 => sprintf(
                __( '%2$s scheduled for: <strong>%1$s</strong>.', $this->textdomain ),
                date_i18n( __( 'M j, Y @ G:i', $this->textdomain ), strtotime( $post->post_date ) ),
                $singular
            ),
            10 => sprintf( __( '%s draft updated.', $this->textdomain ), $singular ),
        );

        return $messages;
    }

    /**
     * Bulk updated messages
     *
     * Internal function that modifies the post type names in bulk updated messages
     *
     * @param array $messages an array of bulk updated messages
     */
    public function bulk_updated_messages( $bulk_messages, $bulk_counts ) {

        $singular = $this->singular;
        $plural = $this->plural;

        $bulk_messages[ $this->post_type_name ] = array(
            'updated'   => _n( '%s '.$singular.' updated.', '%s '.$plural.' updated.', $bulk_counts['updated'] ),
            'locked'    => _n( '%s '.$singular.' not updated, somebody is editing it.', '%s '.$plural.' not updated, somebody is editing them.', $bulk_counts['locked'] ),
            'deleted'   => _n( '%s '.$singular.' permanently deleted.', '%s '.$plural.' permanently deleted.', $bulk_counts['deleted'] ),
            'trashed'   => _n( '%s '.$singular.' moved to the Trash.', '%s '.$plural.' moved to the Trash.', $bulk_counts['trashed'] ),
            'untrashed' => _n( '%s '.$singular.' restored from the Trash.', '%s '.$plural.' restored from the Trash.', $bulk_counts['untrashed'] ),
        );

        return $bulk_messages;
    }

    /**
     * Flush
     *
     * Flush rewrite rules programatically
     */
    public function flush() {
        flush_rewrite_rules();
    }    
}